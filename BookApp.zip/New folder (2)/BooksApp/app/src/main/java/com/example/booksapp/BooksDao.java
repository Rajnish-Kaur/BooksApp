package com.example.booksapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface BooksDao {

    @Insert
    void addNewFavBook(Books c);

    @Query("select * from Books")
    Books[] getAllBooks();

    @Delete
    void deleteABook(Books dc);
}
