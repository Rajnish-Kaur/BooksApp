package com.example.booksapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class BooksAdapter extends RecyclerView.Adapter<BooksAdapter.BookViewHolder> {
    interface ItemListener{
        void onClicked(int post);
    }
    Context context;
    ArrayList<Books> list;
    //ItemListener listener;
    public BooksAdapter(Context context, ArrayList<Books> booksArrayList) {
        this.context = context;
       this.list = booksArrayList;
    }
    @NonNull
    @Override
    public BooksAdapter.BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.books_list,parent,false);
        return new BookViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Books books = list.get(position);
        holder.booktitleTV.setText(books.title);
        holder.pageCountTV.setText("No of Pages : " + books.pageCount);
        holder.dateTV.setText(books.publishedDate);


        holder.author.setText(books.authorname);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {

            URL url = new URL(books.thumbnail);
            //HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = url.openStream();//new BufferedInputStream(urlConnection.getInputStream());
            Bitmap imageData = BitmapFactory.decodeStream(in);
            holder.coverIV.setImageBitmap(imageData);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, BookDetail.class);
                i.putExtra("title", books.title);
//                i.putExtra("authors", books.getAuthors());
                i.putExtra("publisher", books.publisher);
                i.putExtra("publishedDate", books.publishedDate);
                i.putExtra("description", books.description);
                i.putExtra("pageCount", books.pageCount);
                i.putExtra("authors", books.authorname);
                i.putExtra("imagelink",books.thumbnail );
//                i.putExtra("thumbnail", books.getThumbnail());
//                i.putExtra("previewLink", books.getPreviewLink());
//                i.putExtra("infoLink", books.getInfoLink());
//                i.putExtra("buyLink", books.getBuyLink());
                //after passing that data we are starting our new  intent.
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class BookViewHolder extends RecyclerView.ViewHolder {
        TextView booktitleTV, author, pageCountTV, dateTV;
        ImageView coverIV;
        String smallThumbnail;
        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            booktitleTV= itemView.findViewById(R.id.bookTitle);
            author= itemView.findViewById(R.id.author);
            pageCountTV= itemView.findViewById(R.id.pageCount);
            dateTV = itemView.findViewById(R.id.date);
            coverIV = itemView.findViewById(R.id.cover);


        }
    }
}
