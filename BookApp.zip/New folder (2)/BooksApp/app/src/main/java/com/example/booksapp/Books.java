package com.example.booksapp;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class Books implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    int id;
    String title;
    String publisher;
    String publishedDate;
    String description;
    int pageCount;
    String authorname;
    String thumbnail;
    public Books(String title, String publisher, String publishedDate, String description, int pageCount, String authorname, String thumbnail) {

        this.title = title;
        this.publisher = publisher;
        this.publishedDate = publishedDate;
        this.description = description;
        this.pageCount = pageCount;
        this.authorname = authorname;
        this.thumbnail = thumbnail;
    }

    protected Books(Parcel in) {
        id = in.readInt();
        title = in.readString();
        publisher = in.readString();
        publishedDate = in.readString();
        description = in.readString();
        pageCount = in.readInt();
        authorname = in.readString();
        thumbnail = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(publisher);
        dest.writeString(publishedDate);
        dest.writeString(description);
        dest.writeInt(pageCount);
        dest.writeString(authorname);
        dest.writeString(thumbnail);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Books> CREATOR = new Creator<Books>() {
        @Override
        public Books createFromParcel(Parcel in) {
            return new Books(in);
        }

        @Override
        public Books[] newArray(int size) {
            return new Books[size];
        }
    };
}
