package com.example.booksapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.Arrays;

public class Mybookshelf_activity extends AppCompatActivity
        implements DBManager.DataBaseListener,BooksAdapter.ItemListener{
          BooksAdapter adapter;
          ArrayList<Books> blist = new ArrayList<>(0);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mybookshelf);
        this.setTitle("MybookShelf");
        RecyclerView booksshelf = findViewById(R.id.booksShelf);
        adapter = new BooksAdapter(this,blist);
        booksshelf.setAdapter(adapter);


        booksshelf.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        ((MyApp) getApplication()).dbManager.getDB(this);
        ((MyApp) getApplication()).dbManager.getAllCities();
        ((MyApp) getApplication()).dbManager.listener = this;

    }
    @Override
    public void onClicked(int post) {

    }

    @Override
    public void insertingBooksInfoCompleted() {

    }

    @Override
    public void gettingBooksCompleted(Books[] list) {
        blist = new ArrayList( Arrays.asList(list));
        adapter.list = blist;
        adapter.notifyDataSetChanged();

    }

    @Override
    public void deleteABookInfoCompleted() {

    }


}