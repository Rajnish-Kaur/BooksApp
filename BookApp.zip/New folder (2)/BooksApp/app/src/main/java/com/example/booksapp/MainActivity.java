package com.example.booksapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NetworkingService.NetworkingListener, View.OnClickListener {
    RecyclerView bookslist;
    BooksAdapter adaptor;
    ArrayList<Books> list = new ArrayList<>(0);
    TextView tv_favourite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((MyApp) getApplication()).networkingService.listener = this;
        bookslist = findViewById(R.id.Books);
        tv_favourite = findViewById(R.id.tv_favourite);
        adaptor = new BooksAdapter(this, list);
        bookslist.setAdapter(adaptor);
        bookslist.setLayoutManager(new LinearLayoutManager(this));

        tv_favourite.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.books_search_menu, menu);
        MenuItem searchViewMenu = menu.findItem(R.id.BooksSearch);

        SearchView searchView = (SearchView) searchViewMenu.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //  Log.d("Donation app submit",query);


                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //  Log.d("Donation app change",newText);
                if (newText.length() >= 3) {
                    ((MyApp) getApplication()).networkingService.getAllBooks(newText);
                    //search for books with three charactors
                } else {
                    adaptor.list = new ArrayList<>(0);
                    adaptor.notifyDataSetChanged();
                }

                return false;
            }
        });


        return true;
    }

    @Override
    public void gettingJsonIsCompleted(String json) {
        //
        list = JSONservice.fromJSONToList(json);
        adaptor.list = list;
        adaptor.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tv_favourite:
                startActivity(new Intent(MainActivity.this,Mybookshelf_activity.class));
                break;
        }
    }
}