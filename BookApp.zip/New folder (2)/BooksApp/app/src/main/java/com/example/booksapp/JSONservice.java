package com.example.booksapp;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JSONservice {

        static ArrayList<Books> fromJSONToList(String jsonString) {
                ArrayList<Books> list = new ArrayList<>(0);

        try {
            JSONObject jsonObject = new JSONObject(jsonString);

            JSONArray jsonArray = jsonObject.getJSONArray("items");
            for (int i = 0 ; i< jsonArray.length(); i++){
                Log.d("BooksApp", jsonArray.getString(i));
                String title = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getString("title");
                String publisher = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getString("publisher");
                String publishedDate = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getString("publishedDate");
                String description = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getString("description");
                int pageCount = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getInt("pageCount");
                JSONArray authorArray = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getJSONArray("authors");
                String authorname = "";
                for(int j = 0 ; j < authorArray.length() ; j++) {
                    try {
                        authorname = authorname+ ","+authorArray.get(i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                JSONObject imageLinks = jsonArray.getJSONObject(i).getJSONObject("volumeInfo").getJSONObject("imageLinks");
                String thumbnail = imageLinks.getString("smallThumbnail");
                list.add(new Books(title,publisher,publishedDate,description,pageCount,authorname,thumbnail));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return list;
    }
}