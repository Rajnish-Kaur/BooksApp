package com.example.booksapp;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class BookDetail extends AppCompatActivity implements View.OnClickListener,
        DBManager.DataBaseListener {
    String title, publisher, publishedDate, description, imagelink,authors;
    int pageCount;

    TextView titleTV, publisherTV, descTV, pageTV, publishDateTV,author;
    Button Addtomyshelf;
    private ImageView coverIV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.books_activity);

        ((MyApp)getApplication()).dbManager.listener = this;
        ((MyApp)getApplication()).dbManager.getDB(this);
        //initializing our views..
        titleTV = findViewById(R.id.Title);
        publisherTV = findViewById(R.id.publisher);
        descTV = findViewById(R.id.Description);
        pageTV = findViewById(R.id.PageCount);
        publishDateTV = findViewById(R.id.Date);
        Addtomyshelf = findViewById(R.id.AddButton);
        coverIV = findViewById(R.id.cover);
        author = findViewById(R.id.author);

        Addtomyshelf.setOnClickListener(this);
        Log.e( "onCreate: :::::::::::::", "jnnnnnnnnnnnn");
        //getting the data which we have passesd from our adapter class.
        title = getIntent().getStringExtra("title");
        publisher = getIntent().getStringExtra("publisher");
        publishedDate = getIntent().getStringExtra("publishedDate");
        description = getIntent().getStringExtra("description");
        pageCount = getIntent().getIntExtra("pageCount", 0);
        authors = getIntent().getStringExtra("authors");
        imagelink = getIntent().getStringExtra("imagelink");

        URL url = null;
        try {
            url = new URL( imagelink);
            InputStream in = url.openStream();//new BufferedInputStream(urlConnection.getInputStream());
            Bitmap imageData = BitmapFactory.decodeStream(in);
            coverIV.setImageBitmap(imageData);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();


        //after getting the data we are setting that data to our text views and image view.
        titleTV.setText("Title : "+ title);
        publisherTV.setText("Publisher : "+ publisher);
        publishDateTV.setText("Published On : "+ publishedDate);
        descTV.setText("Description :  "+ description);
        author.setText("Author : "+ authors);
        pageTV.setText("No Of Pages :  "+ pageCount);
//        Picasso.get().load(thumbnail).into(bookIV);
    }

    void showAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to save "+ title+" to the DB??");
        builder.setNegativeButton("No",null);
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                ((MyApp)getApplication()).dbManager.insertNewBooksInfoAsync(new Books(title,publisher,publishedDate,description,pageCount,authors,imagelink));
            }
        });
        builder.create().show();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.AddButton:
                showAlert();
                break;
        }
    }
    @Override
    public void insertingBooksInfoCompleted() {
    }
    @Override
    public void gettingBooksCompleted(Books[] list) {

    }

    @Override
    public void deleteABookInfoCompleted() {

    }
}
