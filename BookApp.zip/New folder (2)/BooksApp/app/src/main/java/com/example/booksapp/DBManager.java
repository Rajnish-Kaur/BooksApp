package com.example.booksapp;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.room.Room;

public class DBManager {

    interface DataBaseListener{
        void insertingBooksInfoCompleted();
        void gettingBooksCompleted(Books[] list);
        void deleteABookInfoCompleted();
    }

    DataBaseListener listener;

    BooksDatabase bookDB;
    Handler dbHandler = new Handler(Looper.getMainLooper());

    BooksDatabase getDB(Context context){
        if (bookDB == null)
            bookDB = Room.databaseBuilder(context,BooksDatabase.class,"city_db").build();

        return bookDB;
    }

    void insertNewBooksInfoAsync(Books t){

        MyApp.executorService.execute(new Runnable() {
            @Override
            public void run() {
                bookDB.getDao().addNewFavBook(t);
                dbHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        // notify main thread
                        listener.insertingBooksInfoCompleted();
                    }
                });
            }
        });
    }

    void getAllCities(){
        MyApp.executorService.execute(new Runnable() {
            @Override
            public void run() {
                Books[] list = bookDB.getDao().getAllBooks();
                dbHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        // notify main thread
                        listener.gettingBooksCompleted(list);
                    }
                });
            }
        });
    }
}
